#include <iostream>
#include "Voiture.h"
#include "Carte_grise.h"
using namespace std;

int main()
{
    int val;
    val = 0;

    int val2(10);


    cout << "val : " << val << endl;
    cout << "val2 : " << val2 << endl;


    return 0;
}
